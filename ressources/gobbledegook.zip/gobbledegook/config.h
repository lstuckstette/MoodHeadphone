/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* define if the compiler supports basic C++11 syntax */
#define HAVE_CXX11 1

/* Define to 1 if you have the `gio-2.0' library (-lgio-2.0). */
#define HAVE_LIBGIO_2_0 1

/* Define to 1 if you have the `glib-2.0' library (-lglib-2.0). */
#define HAVE_LIBGLIB_2_0 1

/* Define to 1 if you have the `gobject-2.0' library (-lgobject-2.0). */
#define HAVE_LIBGOBJECT_2_0 1

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Name of package */
#define PACKAGE "ggk"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "ggk"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "ggk 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "ggk"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Version number of package */
#define VERSION "1.0"
